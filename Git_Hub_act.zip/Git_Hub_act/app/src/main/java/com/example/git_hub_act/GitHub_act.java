package com.example.git_hub_act;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import Precio.Precio;

public class GitHub_act extends AppCompatActivity {
    private Spinner spin;
    private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_git_hub_act);

        spin=(Spinner)findViewById(R.id.spn);
        text=(TextView)findViewById(R.id.tv);

        String []libros={"FARENEITH","REVIVAL","EL_AQUIMISTA"};
        ArrayAdapter<String> adapt= new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,libros);
        spin.setAdapter(adapt);

    }

    public void Opcion(View view){
        Precio pr= new Precio();

        String opcion=spin.getSelectedItem().toString();
        if (opcion.equals("FARENEITH")){
            pr.getFareneith();
            int fareneith=5000;
            text.setText("El valor de Fareneith es : "+pr.getFareneith());
        }
        if (opcion.equals("REVIVAL")){
            pr.getRevival();
            int revival=120000;
            text.setText("El valor de revival es : "+pr.getRevival());
        }
        if (opcion.equals("EL_AQUIMISTA")){
            pr.getEl_aquimista();
            int el_aquimista=450000;
            text.setText("El valor d'el aquimista es : "+pr.getEl_aquimista());
        }
    }

}